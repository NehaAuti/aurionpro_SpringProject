package com.aurionpro.mappings.entity;

public enum BankStatus {
	ACTIVE,INACTIVE

}
