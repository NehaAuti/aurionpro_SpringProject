package com.aurionpro.mappings.exception;

public class CustomerNotFoundException extends RuntimeException {

    public CustomerNotFoundException(String message) {
        super();
    }

    public CustomerNotFoundException() {
        super();
    }
}