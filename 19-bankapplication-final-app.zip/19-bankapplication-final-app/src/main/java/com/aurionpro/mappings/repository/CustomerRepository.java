package com.aurionpro.mappings.repository;

import java.util.Optional;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.aurionpro.mappings.entity.Customer;
import com.aurionpro.mappings.entity.Role;
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer>{
//	   Optional<Customer> findByEmailId(String emailId);
//
//	boolean existsByEmailId(String emailId);
//
//	Optional<Role> findByEmail(String emailId);
	
	Optional<Customer> findByEmailId(String emailId);
}
