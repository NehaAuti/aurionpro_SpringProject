package com.aurionpro.mappings.entity;

public enum TransactionType {
    CREDIT, DEBIT, TRANSFER
}
